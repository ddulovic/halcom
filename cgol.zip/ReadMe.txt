
Program is written in Visual Stuido 2015(although you can easily convert it in newer or older version)
---------------------------------------------------------------------------------------------------------------------------------
Build solution :
 	Either from Visual Studio IDE after opening solution (project)
	
	OR
	
 	Run builgameoflife batch file using switch win32 or x64. After build process, exe file is copied in bin directory

	If you are using batch file, be sure that variable in buildgameoflife.bat file, VCVARS2015(line 3) points to 
	correct Visual Stuidio Commons path on your computer. If your Visual Stuidio is installed in default path, 
	you don't need to change anything.

---------------------------------------------------------------------------------------------------------------------------------
	
Using program :
1. 	Switch to bin directory
2. 	From command line run gameoflife with two parameters.
	First parameter is name of application settings xml file(defines size of screen and title)
	Second parameter is name of pattern xml file(defines pattern name, size and live cells)
Example :
	gameoflife appsettings.xml pattern\112P51.xml
	
	paths are relative to location of gameoflife.exe file, but stepback(i.e. ..\) is not supported
	demo settings and patterns files are in bin directory (example command abovee iterates pattern with period of 51)
	
	Besides pattern, program will display basic info (screen/field size, initial pattern size)
	To iterate you will need to press any key, to exit press 'q'
	During iteration pattern(or some portions of it) may get out of bounds. In that case warning on bottom of screen is displayed
	
Screen size :
	Demo field size in appsettings.xml is set to width = 50, height = 50. For most patterns(but not all) it is appropriate,
	but some may be either to small(waring after loading pattern file) or go out of bounds during iterations(also with warning)
Font :
	For better apperance(esspecially with larger patterns) you may want to change you console font to 8x8.
	Console Menu->Properties->Font tab

---------------------------------------------------------------------------------------------------------------------------------

Implementation :
space/field representation 
	1 bit per cell(i.e. 8 cells in byte) is used. You did not mention anything about field size,
	so this kind of representation seems to be most convinient. For very large field with low population density,
	different kind of representation would be appropriate(list of live cells instead of matrix, 
	but it is more complicated to implement and for higher density is less optimal than used representaion)
	
no third party libraries are used
	xml parsering is done using msxml3 library that should be shipped with Windows.
	
CGameOfLifeBasic.cpp/h 
	Contains Game Of Life logic and field representation. It should be platform agnostic, i.e. only standard
	C++ functions are used.(Although I did not try compile in Linux). xml and console files have Windows specific
	dependencies
		
pattern xml file
	It defines pattern name , size and initial live cells(several known patterns are available in bin\patterns folder)
	Live cells are taken from Run Line Encoding(RLE) files available from internet. 
	It is basically only format used for Conway's Game of Life patterns. Ad-hoc RLE decoder is implemented in CGameOfLifeBasic class
		
---------------------------------------------------------------------------------------------------------------------------------
		
Testing program :	
	Edit GameOfLife\unitTest.h and uncomment line //#define __UNITTESTING__
	Build Solution
	Run solution (program will run several simple test cases and display results in console)
	
	For real life scenario we would need more test cases 
	


