#ifndef __XMLPARSER_H
#define __XMLPARSER_H

#include <string>
using namespace std;
struct Pattern
{
	string	name;
	int		width;
	int		height;
	string	info;
	string	rledata;
};

struct AppSettings
{
	string	title;
	int		screenwidth;
	int		screenheight;
};

bool xmlLoadPattern(string file, Pattern& pat);
bool xmlLoadAppSettings(string file, AppSettings& appset);

#endif