#include "GameOfLife.h"
#include "xmlParser.h"
#include "unitTest.h"
#include <iostream>
#include <string>
#include <stdlib.h>
#include <conio.h>
#include "Shlwapi.h"


void utilPrintPattern(CGameOfLifeBasic& gl, string title)
{
	system("CLS");
	
	cout << title << endl;
	string line = string(gl.GetWidth() + 2,'-');

	cout << line << endl;
	int toprow = gl.GetHeight() - 1;
	for (int r = toprow; r >= 0; r--)
	{
		int w = gl.GetWidth();
		wstring s = L"|";		
		for (int c = 0; c < w; c++)
			if (gl.GetCellValue(c, r) == 1)
				s += L"O";
			else
				s += L" ";
		s += L"|";
		wcout << s << endl;
	}
	cout << line << endl;
}



int main(int argc, char* argv[])
{
#ifdef __UNITTESTING__
	testAll();
#else
	if(argc != 3)
	{
		cout << "Invalid number of program arguments..." << endl;
		cout << "Usage : " << endl;
		cout << "   gameoflife.exe appsettings_file pattern_file" << endl;

		return 0;
	}

	string exename = string(argv[0]);
	size_t pos = exename.rfind('\\');
	string path = "";
	if(pos != string::npos)
		path = exename.substr(0, pos + 1);

	
	string appsettingsfile = path + string(argv[1]);
	if (!::PathFileExistsA(appsettingsfile.c_str()))
	{
		cout << "Missing application settings file : " << appsettingsfile << endl;
		return 0;
	}

	string patternfile = path + string(argv[2]);
	if (!::PathFileExistsA(patternfile.c_str()))
	{
		cout << "Missing pattern file : " << patternfile << endl;
		return 0;
	}

	AppSettings appsett;
	bool bret = xmlLoadAppSettings(appsettingsfile, appsett);
	if(!bret)
	{
		cout << "Error reading application settings file : " << appsettingsfile << endl;
		return 0;
	}

	Pattern pat;
	bret = xmlLoadPattern(patternfile, pat);
	if(!bret)
	{
		cout << "Error loading pattern." << endl;
		return 0;
	}

	if(pat.height > appsett.screenheight || pat.width > appsett.screenwidth)
	{
		cout << "Pattern bounding box is larger then scree size. Change screen size. " << endl;
		return 0;
	}

	CGameOfLifeBasic glEngine;
	bret = glEngine.InitializeFromRLE(pat.rledata, pat.width, pat.height, appsett.screenwidth, appsett.screenheight);
	utilPrintPattern(glEngine, appsett.title);

	int nitercount = 0;
	int ntransition = 0;
	bool boutofbound = false;
	while (true)
	{
		cout << endl << "Pattern name : " << pat.name << " ( initially  x = " << pat.width << ", y = " << pat.height << " )" << endl;
		cout << "Screen size ( x = " << appsett.screenwidth << " , y = " << appsett.screenheight << " )" << endl;
		if (boutofbound)
			cout << "WARNING : pattern is(has been) out of bounds." << endl;

		cout << "Iteration : " << nitercount << endl;
		if (nitercount > 0)
			cout << "Number of transitions : " << ntransition << endl;

		cout << "Press \'q' to quit, any other key to continue ..." << endl;
		wchar_t c;
		c = _getwch();

		if (c == L'q' || c == L'Q')
			break;

		int noutofbound = 0;
		ntransition = glEngine.Iterate(&noutofbound);
		utilPrintPattern(glEngine, appsett.title);
		if (noutofbound)
			boutofbound = true;
		nitercount++;
	}
#endif

	return 0;
}
