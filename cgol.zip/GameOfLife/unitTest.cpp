#include "unitTest.h"


#ifdef __UNITTESTING__

#include "GameOfLife.h"
#include <iostream>
#include <string>

void testFnc0()
{	
	CGameOfLifeBasic glEngine(30, 30);	
	for (unsigned int n = 0; n < 3; n++)
		glEngine.Iterate();

	int lcnt = glEngine.GetLiveCellCnt();

	if (lcnt == 0)
		cout << "Testing Empty(all zeros) Pattern Ok" << endl;
	else
		cout << "Testing Empty(all zeros) Pattern ERROR" << endl;
}

void testFnc1()
{
	CGameOfLifeBasic glEngine(30, MAX_HEIGHT + 1);
	bool berror = glEngine.IsReady();

	CGameOfLifeBasic glEngine1(MAX_WIDTH + 1, 30);
	berror |= glEngine1.IsReady();

	if (!berror)
		cout << "Testing Too Large Pattern Ok" << endl;
	else
		cout << "Testing Too Large Pattern ERROR" << endl;
}

void testFnc2()
{
	CGameOfLifeBasic glEngine(30, 0);
	bool berror = glEngine.IsReady();

	CGameOfLifeBasic glEngine1(0, 30);
	berror |= glEngine1.IsReady();

		if (!berror)
			cout << "Testing Null Pattern Ok" << endl;
		else
			cout << "Testing Null Pattern ERROR" << endl;
}

void testFnc3()
{
	vector<pair<int, int>> diehard{ { 21,22 },{ 22,22 },{ 22,21 },{ 26,21 },{ 27,21 },{ 28,21 }, { 27,23 } };
	CGameOfLifeBasic glEngine(50, 45);
	glEngine.Initialize(diehard);

	for(int n = 0;n < 130;n++)
		glEngine.Iterate();
	
	int nlivecnt = glEngine.GetLiveCellCnt();

	if (nlivecnt == 0)
		cout << "Testing Diehard Ok" << endl;
	else
		cout << "Testing Diehard ERROR" << endl;
}

void testFnc4()
{
	vector<pair<int, int>> block{ { 1,1 },{ 2,1 },{ 1,2 },{ 2,2 } };
	CGameOfLifeBasic glEngine(4, 4);
	glEngine.Initialize(block);
	CGameOfLifeBasic it0 = glEngine;

	glEngine.Iterate();
	CGameOfLifeBasic it1 = glEngine;

	if (it0 == it1)
		cout << "Testing Block Ok" << endl;
	else
		cout << "Testing Block ERROR" << endl;
}


void testFnc5()
{
	vector<pair<int, int>> blinker{ { 1,2 },{ 2,2 },{ 3,2 } };
	CGameOfLifeBasic glEngine(5, 5);
	glEngine.Initialize(blinker);
	CGameOfLifeBasic it0 = glEngine;

	glEngine.Iterate();
	CGameOfLifeBasic it1 = glEngine;

	glEngine.Iterate();
	CGameOfLifeBasic it2 = glEngine;

	glEngine.Iterate();
	CGameOfLifeBasic it3 = glEngine;

	if (it0 == it2 && it1 == it3)
		cout << "Testing Blinker Ok" << endl;
	else
		cout << "Testing Blinker ERROR" << endl;
}

void testFnc6()
{
	CGameOfLifeBasic glEngine;
	bool bret = glEngine.InitializeFromRLE("2bo4bo2b$2ob4ob2o$2bo4bo!", 10, 3, 16, 9);
	CGameOfLifeBasic it0 = glEngine;

	for (int x = 0; x < 15; x++)
		glEngine.Iterate();

	if (glEngine == it0)
		cout << "Testing Pentadecathlon(period 15) Ok" << endl;
	else
		cout << "Testing Pentadecathlon ERROR" << endl;
};

void testFnc7()
{
	CGameOfLifeBasic glEngine;
	bool bret = glEngine.InitializeFromRLE("21bo13b$19b3o13b$18bo8bo2b2o3b$9b2o7b2o6bobo2bo3b$10bo15bobobo4b$10bobo12b2obob2o3b$11b2o11bo3bo3bo2b$19bo4bo4bobobob$6b2o9b2ob2o2bo3b2o3bob$5bo2bo10bo4bo4bob2o2b$o2bo2bobo15bo3bo6b$5obob2o15b2obob5o$6bo3bo15bobo2bo2bo$2b2obo4bo4bo10bo2bo5b$bo3b2o3bo2b2ob2o9b2o6b$bobobo4bo4bo19b$2bo3bo3bo11b2o11b$3b2obob2o12bobo10b$4bobobo15bo10b$3bo2bobo6b2o7b2o9b$3b2o2bo8bo18b$13b3o19b$13bo!",
		35, 23, 40, 40);
	CGameOfLifeBasic it0 = glEngine;

	for (int x = 0; x < 25; x++)
		glEngine.Iterate();

	if (glEngine == it0)
		cout << "Testing 134P25 (period 25) Ok" << endl;
	else
		cout << "Testing  134P25 ERROR" << endl;
};


void testAll()
{
	testFnc0();
	testFnc1();
	testFnc2();
	testFnc3();
	testFnc4();
	testFnc5();	
	testFnc6();	
	testFnc7();
}


#endif


