
//#define __UNITTESTING__

#ifdef __UNITTESTING__
	void testAll();
#endif