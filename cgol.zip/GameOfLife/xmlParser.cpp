#include "xmlParser.h"
#include <vector>
#import <msxml3.dll>

using namespace std;

bool xmlLoadPattern(string file, Pattern& pat)
{
	CoInitialize(NULL);
	try
	{
		//read XML
		MSXML2::IXMLDOMDocumentPtr spXMLDoc;
		spXMLDoc.CreateInstance(__uuidof(MSXML2::DOMDocument30));
		spXMLDoc->load(file.c_str());

		MSXML2::IXMLDOMElementPtr spRoot = spXMLDoc->documentElement; //root node
		if(!spRoot)
		{
			spRoot.Release();
			spXMLDoc.Release();
			CoUninitialize();
			return false;
		}

		if (spRoot->nodeName == (_bstr_t)"Pattern")
		{
			MSXML2::IXMLDOMNodeListPtr spNodeList = spRoot->childNodes;

			// traverse child's nodes
			for (long i = 0; i != spNodeList->length; ++i)
			{
				MSXML2::IXMLDOMNodePtr spNode = spNodeList->item[i];
				if (spNode->nodeName == (_bstr_t)"Name")
				{
					pat.name = string((char *)spNode->Gettext());
				}
				else if (spNode->nodeName == (_bstr_t)"RleData")
				{
					pat.rledata = string((char *)spNode->Gettext());
				}
				else if (spNode->nodeName == (_bstr_t)"BoundingBox")
				{
					// traverse node's attributes
					MSXML2::IXMLDOMNamedNodeMapPtr spNameNodeMap = spNode->attributes;
					for (long j = 0; j != spNameNodeMap->length; ++j)
					{
						MSXML2::IXMLDOMNodePtr spNode2 = spNameNodeMap->item[j];

						if (spNode2->nodeName == (_bstr_t)"width")
							pat.width = (int)spNode2->nodeValue;
						else if (spNode2->nodeName == (_bstr_t)"height")
							pat.height = (int)spNode2->nodeValue;
					}
				}
			}
		}

		spRoot.Release();
		spXMLDoc.Release();

		if (pat.height <= 0 || pat.width <= 0 || pat.rledata.length() == 0)
			return false;

		return true;
	}
	catch (...)
	{
		return false;
	}

	CoUninitialize();

	return true;
}

bool xmlLoadAppSettings(string file, AppSettings& appset)
{
	CoInitialize(NULL);
	try
	{
		//read XML
		MSXML2::IXMLDOMDocumentPtr spXMLDoc;
		spXMLDoc.CreateInstance(__uuidof(MSXML2::DOMDocument30));
		spXMLDoc->load(file.c_str());

		MSXML2::IXMLDOMElementPtr spRoot = spXMLDoc->documentElement; //root node
		if (!spRoot)
		{
			spRoot.Release();
			spXMLDoc.Release();
			CoUninitialize();
			return false;
		}

		if (spRoot->nodeName == (_bstr_t)"Settings")
		{
			MSXML2::IXMLDOMNodeListPtr spNodeList = spRoot->childNodes;

			// traverse child's nodes
			for (long i = 0; i != spNodeList->length; ++i)
			{
				MSXML2::IXMLDOMNodePtr spNode = spNodeList->item[i];
				if (spNode->nodeName == (_bstr_t)"Title")
				{
					appset.title = string((char *)spNode->Gettext());
				}
				else if (spNode->nodeName == (_bstr_t)"Screen")
				{
					// traverse node's attributes
					MSXML2::IXMLDOMNamedNodeMapPtr spNameNodeMap = spNode->attributes;
					for (long j = 0; j != spNameNodeMap->length; ++j)
					{
						MSXML2::IXMLDOMNodePtr spNode2 = spNameNodeMap->item[j];

						if (spNode2->nodeName == (_bstr_t)"width")
							appset.screenwidth = (int)spNode2->nodeValue;
						else if (spNode2->nodeName == (_bstr_t)"height")
							appset.screenheight = (int)spNode2->nodeValue;
					}
				}
			}
		}

		spRoot.Release();
		spXMLDoc.Release();

		if (appset.screenheight <= 0 || appset.screenwidth <= 0 )
			return false;

		return true;
	}
	catch (...)
	{
		return false;
	}

	CoUninitialize();

	return true;

}