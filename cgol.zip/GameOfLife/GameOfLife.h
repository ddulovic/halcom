#ifndef __GAMEOFLIFE_H
#define __GAMEOFLIFE_H

#include <vector>
using namespace std;

#define MAX_WIDTH 1000
#define MAX_HEIGHT 1000
typedef vector<vector<unsigned char>> livingspace;

class CGameOfLifeBasic
{
public:
	CGameOfLifeBasic() : width(0), height(0) { };
	CGameOfLifeBasic(int w, int h);
	CGameOfLifeBasic(const CGameOfLifeBasic& r);
	CGameOfLifeBasic& operator=(CGameOfLifeBasic& r);
	bool operator==(CGameOfLifeBasic& r);

	livingspace&	GetSpace() { return space; };
	void			Initialize(vector<pair<int, int>>& vlivePnt);
	bool			InitializeFromRLE(string pattern, int bbw, int bbh, int w, int h);
	int				Iterate(int *ptr_outofbound = nullptr);
	bool			IsReady() { return width > 0 && height > 0; };

	int				GetWidth() { return width; };
	int				GetHeight() { return height; };
	char			GetCellValue(int x, int y);
	bool			SetCellValue(int x, int y, unsigned char val);
	int				GetLiveCellCnt();
private:
	void			CreateSpace(int w, int h);
	void			ClearSpace();
	int				GetLiveNeighboursCnt(int x, int y);
	void			AddLineFromRLE(vector<unsigned char>& line);

	int width;
	int height;
	livingspace space;
};

#endif