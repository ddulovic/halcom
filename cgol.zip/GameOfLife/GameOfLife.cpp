﻿// GameOfLife.cpp 

#include "GameOfLife.h"
#include <iostream>
#include <string>

using namespace std;

unsigned char mask[] = { 0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40, 0x80 };

CGameOfLifeBasic::CGameOfLifeBasic(int w, int h)
{
	width = 0;
	height = 0;
	if (w < 1 || h < 1)
	{
		cout << "Invalid field size" << endl;
		return;
	}

	if (w > MAX_WIDTH || h	> MAX_HEIGHT)
	{
		cout << "Invalid field size" << endl;
		return;
	}
	CreateSpace(w, h);
};

CGameOfLifeBasic::CGameOfLifeBasic(const CGameOfLifeBasic& r)
{
	width = r.width;
	height = r.height;
	space = r.space;
}

CGameOfLifeBasic& CGameOfLifeBasic::operator=(CGameOfLifeBasic& r)
{
	if (&r == this)
		return *this;

	width = r.width;
	height = r.height;
	space = r.space;

	return *this;
}

bool CGameOfLifeBasic::operator==(CGameOfLifeBasic& r)
{
	if (width != r.width || height != r.height)
		return false; 

	for (int y = 0; y < height; y++)
		for (int x = 0; x < width; x++)
			if ( GetCellValue(x, y)  != r.GetCellValue(x, y))
				return false;

	return true;
}


void CGameOfLifeBasic::Initialize(vector<pair<int, int>>& vlivePnt)
{
	for (auto it = vlivePnt.begin(); it != vlivePnt.end(); it++)
	{
		int x = it->first;
		int y = it->second;
		if (x >= 0 && x < width && y >= 0 && y << height)
			SetCellValue(x, y, 1);
		else
		{
			cout << "Ignored live point input that is out of bounds x = " << x << ", y = " << y << endl;
		}
	}
}

void CGameOfLifeBasic::AddLineFromRLE(vector<unsigned char>& line)
{
	int bytelen = static_cast<int>(ceill(width / 8.0));
	vector<unsigned char> newline(bytelen, 0);
	for(unsigned x = 0;x < line.size();x++)
	{
		if(line[x] > 0)
		{
			int byteindex = x / 8;
			unsigned char bit = x % 8;
			unsigned char byte = newline[byteindex];
			byte = byte | mask[bit];
			newline[byteindex] = byte;
		}
	}
	space.insert(space.begin(), newline);
}

bool CGameOfLifeBasic::InitializeFromRLE(string pattern, int bbw, int bbh, int w, int h)
{
	try
	{
		if (bbw > w || bbh > h)
			return false;

		width = w;
		height = h;
		int dx = (width - bbw) / 2;
		int dy = (height - bbh) / 2;

		if (pattern.length() == 0)
			return false;

		const char * ptrIn = pattern.c_str();
		int insize = (int)pattern.length();
		space.clear();

		int charindex = 0;
		char c = ptrIn[charindex];
		string countbuff = "";
		int lindex = dx;
		vector<unsigned char> line(width, 0);

		// place empty lines
		for (int n = 0; n < dy; n++)
			AddLineFromRLE(line);;

		while (charindex < insize)
		{
			c = ptrIn[charindex++];
			
			int count = 1;
			if (countbuff.length() > 0)
				count = std::stoi(countbuff);

			if (c == 'b')
			{
				lindex += count;
				countbuff = "";
			}

			if (c == 'o')
			{
				for (int n = 0; n < count; n++)
					line[lindex++] = 1;

				countbuff = "";
			}

			if (c >= '0' && c <= '9')
				countbuff += string(1, c);

			if (c == '$' || c == '!')
			{
				AddLineFromRLE(line);
				lindex = dx;
				countbuff = "";
				std::fill(line.begin(), line.end(), 0);

				for(int n = 0; n < count - 1;n++)
					AddLineFromRLE(line);
			}

			if (c == '!')
			{
				break;
			}
		}

		// something was wrong
		if (space.size() > (unsigned)height)
			return false;

		if (space.size() < (unsigned)height)
		{
			std::fill(line.begin(), line.end(), 0);
			size_t nline = height - space.size();
			for (unsigned n = 0; n < nline; n++)
				AddLineFromRLE(line);
		}

		return true;
	}
	catch (...)
	{
		cout << "Exception converting RLE to pattern..." << endl;
		return false;
	}

	return true;
}


void CGameOfLifeBasic::CreateSpace(int w, int h)
{
	width = w;
	height = h;

	int linebytelen = static_cast<int>(ceill(w / 8.0));

	// space is vector or rows(horizontal lines)
	// to access element at (x, y) use space[y][x]
	// because first index returns row i.e. it is y 
	// and second index is element(column) in that row i.e. x
	for (int r = 0; r < height; r++)
	{
		vector<unsigned char> v(linebytelen, 0);
		space.push_back(v);
	}
}

void	CGameOfLifeBasic::ClearSpace()
{
	for (int r = 0; r < height; r++)
	{
		std::fill(space[r].begin(), space[r].end(), 0);
	}
}

int		CGameOfLifeBasic::GetLiveNeighboursCnt(int x, int y)
{
	// list of (x,y) pairs 
	// that define pixel neighborhood
	static vector<pair<int, int>> neighbours = {
		{ 1,0	},
		{ 1,1	},
		{ 0,1	},
		{ -1,1	},
		{ -1,0	},
		{ -1,-1	},
		{ 0,-1	},
		{ 1,-1	}
	};

	int cnt = 0;
	for (auto& p : neighbours)
	{
		int nx = x + p.first;
		int ny = y + p.second;

		if (nx >= 0 && nx < width && ny >= 0 && ny < height)
			if ( GetCellValue(nx, ny) == 1)
				cnt++;
	}

	return cnt;
}


int CGameOfLifeBasic::Iterate(int *ptr_outofbound)
{
	if (!IsReady())
		return -1;

	int nreproduction = 0;
	int ndiedcell = 0;
	vector<pair<int, int>> newgen;
	for (int x = 0; x < width; x++)
		for (int y = 0; y < height; y++)
		{
			int neighbourCnt = GetLiveNeighboursCnt(x, y);
			if (GetCellValue(x, y))
			{
				// only live cells with 2 or 3 living neighbours 
				// lives to next iteration
				if (neighbourCnt == 2 || neighbourCnt == 3)
					newgen.push_back(std::make_pair(x, y));
				else
					ndiedcell++;
			}
			else
			{
				// dead cell with 3 living neighbours becomes live cell as reproduction
				if (neighbourCnt == 3)
				{
					newgen.push_back(std::make_pair(x, y));
					nreproduction++;
				}
			}
		}

	if (ptr_outofbound)
	{
		int outofbound = 0;
		for (int x = 0; x < width; x++)
		{
			if (GetLiveNeighboursCnt(x, -1))
				outofbound++;

			if (GetLiveNeighboursCnt(x, height))
				outofbound++;
		}

		for (int y = 0; y < height; y++)
		{
			if (GetLiveNeighboursCnt(-1, y))
				outofbound++;

			if (GetLiveNeighboursCnt(width, y))
				outofbound++;
		}

		*ptr_outofbound = outofbound;
	}


	ClearSpace();
	for (auto& p : newgen)
		SetCellValue(p.first, p.second, 1);

	return ndiedcell + nreproduction;
}


char	CGameOfLifeBasic::GetCellValue(int x, int y)
{
	if (x < 0 || x >= width || y < 0 || y >= height)
		return -1;

	int byteindex = x / 8;
	unsigned char bit = x % 8;

	unsigned char byte = space[y][byteindex];	
	unsigned char c = (byte & mask[bit]) >> bit;
	return c;

}

bool CGameOfLifeBasic::SetCellValue(int x, int y, unsigned char val)
{
	if (x < 0 || x >= width || y < 0 || y >= height)
		return false;

	
	int byteindex = x / 8;
	unsigned char bit = x % 8;
	unsigned char byte = space[y][byteindex];
	if (val > 0)
		byte = byte | mask[bit];
	else
		byte = byte & (~(mask[bit]));
	space[y][byteindex] = byte;
	return true;
}

int CGameOfLifeBasic::GetLiveCellCnt()
{
	int lcnt = 0;
	for (int x = 0; x < width; x++)
		for (int y = 0; y < height; y++)
			if (GetCellValue(x, y))
				lcnt++;
	return lcnt;
}




